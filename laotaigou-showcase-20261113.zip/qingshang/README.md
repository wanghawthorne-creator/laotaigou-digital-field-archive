# 箐上专题 / Qingshang series

三期阅读副本、提取文本、作品集摘要和图像使用关系分别存放。第三期仅收录第 5 版上篇的两种视觉阅读副本；没有收录下篇原始稿。来源采集时保存的原始抓取、完整 Sites 源项目和私人工作记录留在本地归档。

Reading copies, extracted texts, portfolio summaries, and image occurrence records are stored separately. Issue 03 includes two visual reading copies of version 5, Part One. The later draft is excluded. Acquisition captures, the complete source project, and private working records remain in the local archive.

See ../README.md and ../COPYRIGHT.md for scope and rights.
