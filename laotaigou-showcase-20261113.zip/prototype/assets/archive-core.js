/* Pure functions also used by the review checks. */
(function (root) {
  const facets = ["type", "year", "person", "place", "theme", "trip"];
  function filterItems(items, state) {
    const query = String(state.q || "").trim().toLocaleLowerCase();
    const results = items.filter(item => facets.every(key => !state[key] || item[key] === state[key]) && (!query || [item.id, item.title, item.text, item.type, item.person, item.place, item.theme, item.trip].join(" ").toLocaleLowerCase().includes(query)));
    return results.sort((a, b) => (!a.year || !b.year) && state.sort !== "title" ? (a.year ? -1 : b.year ? 1 : a.id.localeCompare(b.id)) : state.sort === "oldest" ? a.year.localeCompare(b.year) || a.id.localeCompare(b.id) : state.sort === "title" ? a.title.localeCompare(b.title, "zh-CN") : b.year.localeCompare(a.year) || a.id.localeCompare(b.id));
  }
  function parseState(hash) {
    const params = new URLSearchParams(String(hash).split("?")[1] || "");
    const state = Object.fromEntries([...facets, "q", "sort", "view", "item"].map(key => [key, params.get(key) || ""]));
    state.view = state.view === "list" ? "list" : "grid";
    return state;
  }
  function stateHash(state) {
    const params = new URLSearchParams();
    [...facets, "q", "sort", "view", "item"].forEach(key => { if (state[key] && !(key === "view" && state[key] === "grid")) params.set(key, state[key]); });
    return "#archive" + (params.size ? "?" + params.toString() : "");
  }
  root.ArchiveCore = { filterItems, parseState, stateHash, facets };
})(typeof window !== "undefined" ? window : globalThis);
