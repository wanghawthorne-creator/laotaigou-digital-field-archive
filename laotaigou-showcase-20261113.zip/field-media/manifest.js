/* User-supplied display derivatives; original article sources remain separate. */
window.LTG_MEDIA = {
  "schemaVersion": "1.0",
  "providedAt": "2026-11-11",
  "scope": "本轮 9 张附件的展示衍生版：8 张实拍、1 张手写题字；不修改三期原始归档",
  "sourcePolicy": "原文件保留在用户原有本地位置，未复制到网站展示目录；文件名不用于推断拍摄日期。",
  "comparisonPolicy": "SHA-256 一致才判定字节相同；构图目视一致但字节不同的保留独立文件及来源关系。",
  "assets": [
    {
      "id": "field-01",
      "type": "field-photograph",
      "title": "沿着小路向前走",
      "caption": "一行人沿着树木环绕的小路向前走。",
      "captionKind": "作品集整理图注，依据画面所见；并非原始口述或采访记录",
      "path": "field-media/field-01.jpg",
      "width": 1440,
      "height": 960,
      "bytes": 157789,
      "sha256": "9c7e4f35076977778e6c796c18e38a308faf39c2f76c9580270972c82071a184",
      "originalFilename": "145318799ad8f34d6ebcec9c6676cadb.jpg",
      "originalSha256": "c2406a89a50fd590910baf4f06c94ce9003b33a0869049129050c5d18ecb5725",
      "originalWidth": 1440,
      "originalHeight": 960,
      "originalBytes": 142485,
      "source": "用户在本项目聊天中提供的附件",
      "providedAt": "2026-11-11",
      "captureDate": null,
      "photographer": null,
      "place": null,
      "theme": "田野行走",
      "rights": {
        "copyrightOwner": "待核对",
        "publicRelease": "未确认；本轮仅按用户要求纳入本地预览",
        "portraitConsent": "具体人物及未成年人公开授权范围待核对",
        "reuse": "未经相应权利人许可，不另行授权下载、转载或商业使用；法律允许的使用除外"
      },
      "derivative": {
        "purpose": "网站展示版",
        "maxEdge": 1600,
        "resized": false,
        "cropped": false,
        "contentAltered": false,
        "exifRemoved": true,
        "metadata": "未写入源图 EXIF、GPS、XMP 或注释；题字保留白底"
      },
      "existingMatches": [],
      "suggestedPositions": [
        "首页主图",
        "研究档案：照片"
      ]
    },
    {
      "id": "field-02",
      "type": "field-photograph",
      "title": "山坡上的合照",
      "caption": "红土坡上的合照，画面中有人举起双手，也有人拿着吉他。",
      "captionKind": "作品集整理图注，依据画面所见；并非原始口述或采访记录",
      "path": "field-media/field-02.jpg",
      "width": 1600,
      "height": 1066,
      "bytes": 485631,
      "sha256": "84e5b69a17291e5119df55283d1ce62a5f3e2e7767afae55a8a029c0279331c2",
      "originalFilename": "微信图片_20261006154844_210_1.jpg",
      "originalSha256": "5ce67b0a1831e39d59148f8519c83a84cc761c718553397a3fa3f53b73af0720",
      "originalWidth": 1919,
      "originalHeight": 1279,
      "originalBytes": 1948192,
      "source": "用户在本项目聊天中提供的附件",
      "providedAt": "2026-11-11",
      "captureDate": null,
      "photographer": null,
      "place": null,
      "theme": "相聚",
      "rights": {
        "copyrightOwner": "待核对",
        "publicRelease": "未确认；本轮仅按用户要求纳入本地预览",
        "portraitConsent": "具体人物及未成年人公开授权范围待核对",
        "reuse": "未经相应权利人许可，不另行授权下载、转载或商业使用；法律允许的使用除外"
      },
      "derivative": {
        "purpose": "网站展示版",
        "maxEdge": 1600,
        "resized": true,
        "cropped": false,
        "contentAltered": false,
        "exifRemoved": true,
        "metadata": "未写入源图 EXIF、GPS、XMP 或注释；题字保留白底"
      },
      "existingMatches": [
        {
          "assetId": "LTG-AS-2026-0047",
          "sourceId": "LTG-WA-2026-001-WX20261104",
          "path": "qingshang/media/6b173b7cadc85b3356fa495c937933ba9dd94f89e4a847cb8b4539071dd95860.jpg",
          "relation": "same-photograph-different-file",
          "verification": "逐张目视核对构图与内容；文件尺寸和编码不同，未作字节去重",
          "note": "保持已归档公众号版本及其水印；本次附件作为独立提供版本，不覆盖原件。"
        }
      ],
      "suggestedPositions": [
        "首页田野图集",
        "研究档案：照片"
      ]
    },
    {
      "id": "field-03",
      "type": "field-photograph",
      "title": "蓝布上的针线",
      "caption": "一位老人用针线在蓝色布料上绣花。",
      "captionKind": "作品集整理图注，依据画面所见；并非原始口述或采访记录",
      "path": "field-media/field-03.jpg",
      "width": 1440,
      "height": 810,
      "bytes": 102558,
      "sha256": "24857458c779357db4047795e2fafe209753344d18f88695643d4cc0e5b8f514",
      "originalFilename": "微信图片_20261006154844_205_1.jpg",
      "originalSha256": "332923b80a657dcee2f029b7cf0df27899b6851286afb64eed50bd05730a54d7",
      "originalWidth": 1440,
      "originalHeight": 810,
      "originalBytes": 205975,
      "source": "用户在本项目聊天中提供的附件",
      "providedAt": "2026-11-11",
      "captureDate": null,
      "photographer": null,
      "place": null,
      "theme": "手艺",
      "rights": {
        "copyrightOwner": "待核对",
        "publicRelease": "未确认；本轮仅按用户要求纳入本地预览",
        "portraitConsent": "具体人物及未成年人公开授权范围待核对",
        "reuse": "未经相应权利人许可，不另行授权下载、转载或商业使用；法律允许的使用除外"
      },
      "derivative": {
        "purpose": "网站展示版",
        "maxEdge": 1600,
        "resized": false,
        "cropped": false,
        "contentAltered": false,
        "exifRemoved": true,
        "metadata": "未写入源图 EXIF、GPS、XMP 或注释；题字保留白底"
      },
      "existingMatches": [
        {
          "assetId": "LTG-AS-2026-0032",
          "sourceId": "LTG-WA-2026-001-WX20261104",
          "path": "qingshang/media/0fe88a97789e0e99be6c6eec8c23f9181ef22c15209f468dacd59c07c926c119.jpg",
          "relation": "same-photograph-different-file",
          "verification": "逐张目视核对构图与内容；文件尺寸和编码不同，未作字节去重",
          "note": "保持已归档公众号版本及其水印；本次附件作为独立提供版本，不覆盖原件。"
        }
      ],
      "suggestedPositions": [
        "首页田野图集",
        "研究档案：照片"
      ]
    },
    {
      "id": "field-04",
      "type": "field-photograph",
      "title": "田间的山药劳动",
      "caption": "人们在田间整理带着泥土的山药，身旁是成捆的枝杆。",
      "captionKind": "作品集整理图注，依据画面所见；并非原始口述或采访记录",
      "path": "field-media/field-04.jpg",
      "width": 1600,
      "height": 1069,
      "bytes": 271555,
      "sha256": "8fef93498ca35cedda9fcfb146f7e9751ace69881f6005c9d855c31645bbe5ae",
      "originalFilename": "微信图片_20261006154844_206_1.jpg",
      "originalSha256": "a4f83cb6eab48252e575f760804c5c271fabce85a72fa5712a2e458bc096356e",
      "originalWidth": 1916,
      "originalHeight": 1280,
      "originalBytes": 1224524,
      "source": "用户在本项目聊天中提供的附件",
      "providedAt": "2026-11-11",
      "captureDate": null,
      "photographer": null,
      "place": null,
      "theme": "劳动",
      "rights": {
        "copyrightOwner": "待核对",
        "publicRelease": "未确认；本轮仅按用户要求纳入本地预览",
        "portraitConsent": "具体人物及未成年人公开授权范围待核对",
        "reuse": "未经相应权利人许可，不另行授权下载、转载或商业使用；法律允许的使用除外"
      },
      "derivative": {
        "purpose": "网站展示版",
        "maxEdge": 1600,
        "resized": true,
        "cropped": false,
        "contentAltered": false,
        "exifRemoved": true,
        "metadata": "未写入源图 EXIF、GPS、XMP 或注释；题字保留白底"
      },
      "existingMatches": [
        {
          "assetId": "LTG-AS-2026-0031",
          "sourceId": "LTG-WA-2026-001-WX20261104",
          "path": "qingshang/media/2ca88cd7aaaff0d82491a0d1ccad16b2137ea657b56079986cc55cac20f55e05.jpg",
          "relation": "same-photograph-different-file",
          "verification": "逐张目视核对构图与内容；文件尺寸和编码不同，未作字节去重",
          "note": "保持已归档公众号版本及其水印；本次附件作为独立提供版本，不覆盖原件。"
        }
      ],
      "suggestedPositions": [
        "首页田野图集",
        "研究档案：照片"
      ]
    },
    {
      "id": "field-05",
      "type": "field-photograph",
      "title": "草地上的观察",
      "caption": "两个孩子蹲在草地上，俯身查看放在面前的网笼。",
      "captionKind": "作品集整理图注，依据画面所见；并非原始口述或采访记录",
      "path": "field-media/field-05.jpg",
      "width": 1600,
      "height": 1067,
      "bytes": 334947,
      "sha256": "3b8beb3ee29ff3603ff187fe0a49c0d61c5854c1af49f52642d2eb27ed0ebc9f",
      "originalFilename": "微信图片_20261006154844_212_1.jpg",
      "originalSha256": "e4260d7488604b36a94533631f9f0940dbecd6dfd56a3ec54d3ed214f4e947fc",
      "originalWidth": 1920,
      "originalHeight": 1280,
      "originalBytes": 1486073,
      "source": "用户在本项目聊天中提供的附件",
      "providedAt": "2026-11-11",
      "captureDate": null,
      "photographer": null,
      "place": null,
      "theme": "儿童观察",
      "rights": {
        "copyrightOwner": "待核对",
        "publicRelease": "未确认；本轮仅按用户要求纳入本地预览",
        "portraitConsent": "具体人物及未成年人公开授权范围待核对",
        "reuse": "未经相应权利人许可，不另行授权下载、转载或商业使用；法律允许的使用除外"
      },
      "derivative": {
        "purpose": "网站展示版",
        "maxEdge": 1600,
        "resized": true,
        "cropped": false,
        "contentAltered": false,
        "exifRemoved": true,
        "metadata": "未写入源图 EXIF、GPS、XMP 或注释；题字保留白底"
      },
      "existingMatches": [
        {
          "assetId": "LTG-AS-2026-0038",
          "sourceId": "LTG-WA-2026-001-WX20261104",
          "path": "qingshang/media/2df8fe9d6c3515b91e3a336f471db977dd698335e78b39be96665cf6c91d5848.jpg",
          "relation": "same-photograph-different-file",
          "verification": "逐张目视核对构图与内容；文件尺寸和编码不同，未作字节去重",
          "note": "保持已归档公众号版本及其水印；本次附件作为独立提供版本，不覆盖原件。"
        }
      ],
      "suggestedPositions": [
        "首页田野图集",
        "研究档案：照片"
      ]
    },
    {
      "id": "field-06",
      "type": "field-photograph",
      "title": "田地与村庄",
      "caption": "红土田地上叠放着枝杆，远处是村庄和山坡。",
      "captionKind": "作品集整理图注，依据画面所见；并非原始口述或采访记录",
      "path": "field-media/field-06.jpg",
      "width": 1600,
      "height": 1068,
      "bytes": 281639,
      "sha256": "f622f35a8776f09605e1c92b7ed42631ff5f223fded2e1509ecad1d7fdc03646",
      "originalFilename": "微信图片_20261006154844_213_1.jpg",
      "originalSha256": "e3c8548c92c02bc524b023c00d08a92318d50106178959458057699f48dd46df",
      "originalWidth": 1916,
      "originalHeight": 1279,
      "originalBytes": 1144129,
      "source": "用户在本项目聊天中提供的附件",
      "providedAt": "2026-11-11",
      "captureDate": null,
      "photographer": null,
      "place": null,
      "theme": "地方景观",
      "rights": {
        "copyrightOwner": "待核对",
        "publicRelease": "未确认；本轮仅按用户要求纳入本地预览",
        "portraitConsent": "具体人物及未成年人公开授权范围待核对",
        "reuse": "未经相应权利人许可，不另行授权下载、转载或商业使用；法律允许的使用除外"
      },
      "derivative": {
        "purpose": "网站展示版",
        "maxEdge": 1600,
        "resized": true,
        "cropped": false,
        "contentAltered": false,
        "exifRemoved": true,
        "metadata": "未写入源图 EXIF、GPS、XMP 或注释；题字保留白底"
      },
      "existingMatches": [
        {
          "assetId": "LTG-AS-2026-0022",
          "sourceId": "LTG-WA-2026-001-WX20261104",
          "path": "qingshang/media/26ad71d7fe140b84b24cde50cb66103e5e7894093eec7c56d97a0025b0d8b700.jpg",
          "relation": "same-photograph-different-file",
          "verification": "逐张目视核对构图与内容；文件尺寸和编码不同，未作字节去重",
          "note": "保持已归档公众号版本及其水印；本次附件作为独立提供版本，不覆盖原件。"
        }
      ],
      "suggestedPositions": [
        "首页田野图集",
        "研究档案：照片"
      ]
    },
    {
      "id": "field-07",
      "type": "field-photograph",
      "title": "树下与乐器",
      "caption": "一群人在大树下相聚，画面中可见鼓和弦乐器。",
      "captionKind": "作品集整理图注，依据画面所见；并非原始口述或采访记录",
      "path": "field-media/field-07.jpg",
      "width": 1600,
      "height": 1068,
      "bytes": 562241,
      "sha256": "3b38bb09a1b54f54e66b8f49b168cfe233f36e3bc7f55d24771243b012eb95aa",
      "originalFilename": "微信图片_20261006154844_214_1.jpg",
      "originalSha256": "3161f9e69db8b786860e4f118c849d3e75622d9491cfbe513a65ce07b045292a",
      "originalWidth": 1916,
      "originalHeight": 1279,
      "originalBytes": 841212,
      "source": "用户在本项目聊天中提供的附件",
      "providedAt": "2026-11-11",
      "captureDate": null,
      "photographer": null,
      "place": null,
      "theme": "相聚",
      "rights": {
        "copyrightOwner": "待核对",
        "publicRelease": "未确认；本轮仅按用户要求纳入本地预览",
        "portraitConsent": "具体人物及未成年人公开授权范围待核对",
        "reuse": "未经相应权利人许可，不另行授权下载、转载或商业使用；法律允许的使用除外"
      },
      "derivative": {
        "purpose": "网站展示版",
        "maxEdge": 1600,
        "resized": true,
        "cropped": false,
        "contentAltered": false,
        "exifRemoved": true,
        "metadata": "未写入源图 EXIF、GPS、XMP 或注释；题字保留白底"
      },
      "existingMatches": [
        {
          "assetId": "LTG-AS-2026-0034",
          "sourceId": "LTG-WA-2026-001-WX20261104",
          "path": "qingshang/media/90800fc3c2a7a493557b8adfa5fa81606d43f52b36bc189cbf20445ca2a07081.jpg",
          "relation": "same-photograph-different-file",
          "verification": "逐张目视核对构图与内容；文件尺寸和编码不同，未作字节去重",
          "note": "保持已归档公众号版本及其水印；本次附件作为独立提供版本，不覆盖原件。"
        }
      ],
      "suggestedPositions": [
        "首页田野图集",
        "研究档案：照片"
      ]
    },
    {
      "id": "field-08",
      "type": "field-photograph",
      "title": "铁路高架旁的田野行走",
      "caption": "一行人走到田边，前方有人抬手示意；农田旁可见铁路高架。",
      "captionKind": "作品集整理图注，依据画面所见；并非原始口述或采访记录",
      "path": "field-media/field-08.jpg",
      "width": 1440,
      "height": 960,
      "bytes": 161591,
      "sha256": "0f6b466ac98bf76937b7ce929a97da74cc3967928d60d69a6b82655c8267e3c4",
      "originalFilename": "微信图片_20261102083938_181_2.jpg",
      "originalSha256": "d6b669ad7e45cf7cc04dcc9f02fa161d04f7e96eec09a92e302cc5d1e1c81105",
      "originalWidth": 1440,
      "originalHeight": 960,
      "originalBytes": 144427,
      "source": "用户在本项目聊天中提供的附件",
      "providedAt": "2026-11-11",
      "captureDate": null,
      "photographer": null,
      "place": null,
      "theme": "田野行走",
      "rights": {
        "copyrightOwner": "待核对",
        "publicRelease": "未确认；本轮仅按用户要求纳入本地预览",
        "portraitConsent": "具体人物及未成年人公开授权范围待核对",
        "reuse": "未经相应权利人许可，不另行授权下载、转载或商业使用；法律允许的使用除外"
      },
      "derivative": {
        "purpose": "网站展示版",
        "maxEdge": 1600,
        "resized": false,
        "cropped": false,
        "contentAltered": false,
        "exifRemoved": true,
        "metadata": "未写入源图 EXIF、GPS、XMP 或注释；题字保留白底"
      },
      "existingMatches": [
        {
          "assetId": "LTG-AS-2026-0007",
          "sourceId": "LTG-WA-2026-003-V05",
          "path": "qingshang/media/d6b669ad7e45cf7cc04dcc9f02fa161d04f7e96eec09a92e302cc5d1e1c81105.jpg",
          "relation": "byte-identical",
          "verification": "SHA-256 一致",
          "note": "同一素材的本次提供关系另行保存，不计作另一场田野活动。"
        }
      ],
      "suggestedPositions": [
        "首页田野图集",
        "研究档案：照片"
      ]
    },
    {
      "id": "qingshang-wordmark",
      "type": "wordmark",
      "title": "手写「箐上」题字",
      "caption": "白底黑字的「箐上」手写题字，作为刊物标识使用。",
      "captionKind": "作品集整理图注，依据画面所见；并非原始口述或采访记录",
      "path": "field-media/qingshang-wordmark.png",
      "width": 1504,
      "height": 1046,
      "bytes": 950205,
      "sha256": "c3ee5444e34bc44d28dc2e4a02f1c8a352923a59c2e05a5672a30bff308ac9f7",
      "originalFilename": "微信图片_20261028155612_126_2.png",
      "originalSha256": "8e0390a64de5161282508314cc708ac886198d7599b027b2b0b9dbe4af20d0e3",
      "originalWidth": 1504,
      "originalHeight": 1046,
      "originalBytes": 1293752,
      "source": "用户在本项目聊天中提供的附件",
      "providedAt": "2026-11-11",
      "captureDate": null,
      "photographer": null,
      "place": null,
      "theme": "刊物标识",
      "rights": {
        "copyrightOwner": "待核对",
        "publicRelease": "未确认；本轮仅按用户要求纳入本地预览",
        "portraitConsent": "不适用",
        "reuse": "未经相应权利人许可，不另行授权下载、转载或商业使用；法律允许的使用除外"
      },
      "derivative": {
        "purpose": "网站展示版",
        "maxEdge": 1600,
        "resized": false,
        "cropped": false,
        "contentAltered": false,
        "exifRemoved": true,
        "metadata": "未写入源图 EXIF、GPS、XMP 或注释；题字保留白底"
      },
      "existingMatches": [],
      "suggestedPositions": [
        "首页箐上专题入口"
      ]
    }
  ]
};
