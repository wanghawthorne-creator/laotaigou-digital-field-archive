/* Public, synthetic view fixtures only. Not canonical research records. */
window.LTG_DEMO = {
  notice: "所有条目均为界面演示，不是已采集的田野材料。",
  person: { id: "DEMO-LTG-PN-2026-001", name: "一位书苑参与者", role: "人物档案 · 演示", description: "在这里，通过一次次交谈、行动与相遇，理解一个人与公共文化空间之间的关系。人物资料将在取得相应授权后录入。" },
  types: ["Photograph", "Audio", "Video", "Interview", "Transcript", "Field Note", "Document", "Map", "Student Work", "Research Note", "Publication", "Web Article"],
  typeLabels: { Photograph: "照片", Audio: "声音", Video: "影像", Interview: "访谈", Transcript: "转写", "Field Note": "田野笔记", Document: "文档", Map: "地图", "Student Work": "儿童作品", "Research Note": "研究札记", Publication: "出版物", "Web Article": "公众号文章" },
  items: [
    { id: "DEMO-LTG-FN-2026-001", type: "Field Note", title: "从一个问题开始", year: "2026", date: "2026 · 日期占位", place: "书苑（演示）", person: "一位书苑参与者（演示）", theme: "田野方法", trip: "2026 · 田野批次演示", format: "text", text: "先记录所见，再区分当时的感受、后来的解释，以及仍需返回现场确认的问题。这是一段页面结构示例。", source: "田野笔记原稿待提供。公开摘录需单独审核。" },
    { id: "DEMO-LTG-IV-2026-001", type: "Interview", title: "与一位参与者的对话", year: "2026", date: "2026 · 日期占位", place: "书苑（演示）", person: "一位书苑参与者（演示）", theme: "公共空间", trip: "2026 · 田野批次演示", format: "audio", text: "访谈结构示例：受访者、访谈者、时间、地点、主题、音频、转写和时间段。没有实际录音或受访者原话。", source: "访谈未导入；音频与转写须分别确认公开范围。" },
    { id: "DEMO-LTG-TR-2026-001", type: "Transcript", title: "关于水的记忆：转写结构", year: "2026", date: "2026 · 日期占位", place: "水源地点（演示）", person: "一位书苑参与者（演示）", theme: "水", trip: "2026 · 田野批次演示", format: "text", text: "00:12:31 主题与时间段的占位示例。真实转写将逐段关联音频与主题；此处没有村民原话。", source: "转写和音频均未提供；时间码来自用户需求中的界面例子。" },
    { id: "DEMO-LTG-MP-2026-001", type: "Map", title: "书苑与村庄：地点关系", year: "2026", date: "2026 · 日期占位", place: "书苑（演示）", person: "", theme: "公共空间", trip: "2026 · 田野批次演示", format: "map", text: "空间关系示意，不是实测地图，不含真实坐标、方位、距离或家庭位置。", source: "地点几何等待核实。公开精度须逐项审核。" },
    { id: "DEMO-LTG-SW-2025-001", type: "Student Work", title: "一张画，等待被讲述", year: "2025", date: "2025 · 日期占位", place: "书苑（演示）", person: "", theme: "儿童", trip: "2025 · 田野批次演示", format: "square", text: "儿童作品的空白位置。作品、署名及附带故事的公开需经过相应授权与审核。", source: "尚未提供作品，不展示任何儿童身份信息。" },
    { id: "DEMO-LTG-RN-2025-001", type: "Research Note", title: "如何理解“扎根”", year: "2025", date: "2025 · 日期占位", place: "书苑（演示）", person: "一位书苑参与者（演示）", theme: "可持续性", trip: "2025 · 田野批次演示", format: "text", text: "研究札记结构：提出问题，列出证据，区分观察与解释，保留反例。本条并非实际研究结论。", source: "研究者解释需人工审核，仅公开审核后的摘录。" },
    { id: "DEMO-LTG-DC-2026-001", type: "Document", title: "教学材料的整理方式", year: "2026", date: "2026 · 日期占位", place: "书苑（演示）", person: "", theme: "教育", trip: "2026 · 田野批次演示", format: "text", text: "文档样本占位：保留来源、版本、使用语境和关联活动。", source: "无真实文档附件。" },
    { id: "DEMO-LTG-WA-2026-001", type: "Web Article", title: "消失的水 · 文章迁移示例", year: "2026", date: "2026 · 日期占位", place: "水源地点（演示）", person: "", theme: "水", trip: "2026 · 田野批次演示", format: "text", text: "公众号文章在网站重新排版，并记录原始平台、作者、日期、原链接及所引用的档案。这里没有真实公众号文章。", source: "原始文章待提供，本条仅展示关系与元数据。" }
  ]
};
