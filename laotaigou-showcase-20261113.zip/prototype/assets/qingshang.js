(function (root) {
  "use strict";
  const esc = value => String(value ?? "").replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
  const data = () => root.QS_DATA || {issues:[], assets:[], occurrences:[], checks:[], provenance:{}};
  const issues = () => data().issues || [];
  const read = issue => issue.status === "read";
  const text = value => typeof value === "string" ? value : value && typeof value === "object" ? [value.title, value.text || value.description || value.note].filter(Boolean).join("：") : String(value ?? "");
  function resource(value) {
    if (!value) return "";
    const path = String(value);
    if (/^https:\/\//i.test(path)) return path;
    if (/^[a-z]+:|^\/|(?:^|\/)\.\.(?:\/|$)/i.test(path)) return "";
    return (document.body.dataset.resourceRoot || "../") + "qingshang/" + path.replace(/^\.\//, "");
  }
  function link(url, label, className="qs-link", external=false) {
    if(!url) return "";
    return `<a class="${className}" href="${esc(url)}"${external ? ' target="_blank" rel="noopener noreferrer"' : ""}>${esc(label)}<span aria-hidden="true"> ↗</span></a>`;
  }
  function sourceLinks(issue) {
    const urls = new Set(), externalLinks = [];
    function addSource(value, label) {
      if (typeof value !== "string" || !/^https:\/\//i.test(value) || urls.has(value)) return;
      urls.add(value);
      externalLinks.push(link(value, label || (/mp\.weixin\.qq\.com/.test(value) ? "公众号原文" : /chatgpt\.com\/library/.test(value) ? "Library 文件入口" : "原始来源入口"), "qs-link", true));
    }
    addSource(issue.sourceUrl);
    for (const source of issue.sources || []) {
      if (typeof source === "string") addSource(source);
      else if (source) addSource(source.url || source.sourceUrl, source.label || source.linkLabel);
    }
    return `<div class="qs-source-links">${link(resource(issue.originalPath), issue.waterOriginalPath ? "阅读白底版原文" : "阅读归档原文")}${link(resource(issue.waterOriginalPath), "阅读水纹版原文")}${link(resource(issue.textPath), "查看提取全文")}${externalLinks.join("")}</div>`;
  }
  function paragraphs(value) {
    return String(value || "").split(/\n\s*\n|\n/).filter(Boolean).map(p => `<p>${esc(p)}</p>`).join("");
  }
  function list(values, empty="材料尚未提供，暂不作判断。") {
    return Array.isArray(values) && values.length ? `<ul class="qs-list">${values.map(value => `<li>${esc(text(value))}</li>`).join("")}</ul>` : `<p class="qs-muted">${esc(empty)}</p>`;
  }
  function typeOf(asset) { return asset.assetType || asset.type || asset.category || "unknown"; }
  function typeName(value) {
    return ({"field-photograph":"田野实拍","field-photo":"田野实拍","photograph":"田野实拍","handdrawn-map":"手绘地图","hand-drawn-map":"手绘地图","product-image":"产品／器物图","product":"产品／器物图","logo":"标识","caption-decoration":"图注标识","chapter-number":"手写章节数字","composite-text-card":"合成图文卡","generated-background":"生成装饰背景","generated_background":"生成装饰背景","unknown":"类型待核对"})[value] || value;
  }
  function assetFor(image) {
    return (data().assets || []).find(asset => (asset.assetId || asset.id) === (image.assetId || image.id));
  }
  function imageType(image) { return typeOf(image.assetType || image.type || image.category ? image : assetFor(image) || image); }
  function isFieldImage(image) { return ["field-photograph", "field-photo", "photograph"].includes(imageType(image)); }
  function imageCounts(images) {
    const counts = new Map();
    for (const image of images) { const kind = imageType(image); counts.set(kind, (counts.get(kind) || 0) + 1); }
    return [...counts].map(([kind,count])=>`${count} 个${typeName(kind)}图位`).join(" · ");
  }
  function issueMarkAssets(issue, kind) {
    if (!issue) return [];
    const occurrences = (data().occurrences || []).filter(use => issue.sourceId ? use.sourceId === issue.sourceId : (use.issueId || use.articleId) === issue.id);
    const ids = new Set(occurrences.map(use => use.assetId || use.asset_id));
    return (data().assets || []).filter(asset => ids.has(asset.assetId || asset.id) && typeOf(asset) === kind && (asset.mime === "image/png" || /\.png$/i.test(asset.name || asset.path || "")));
  }
  function ordinal(value, issue) {
    const number=Number(value);
    const asset=issueMarkAssets(issue,"chapter-number").find(item => Number(item.chapterNumber) === number || item.name === `number-${number}.png` || (item.path || "").endsWith(`/number-${number}.png`));
    return asset ? `<img class="qs-hand-number" src="${esc(resource(asset.path))}" alt="${number}" loading="lazy">` : esc(String(value).padStart(2,"0"));
  }
  function captionMarker(issue) {
    const asset=issueMarkAssets(issue,"caption-decoration")[0];
    return asset ? `<img class="qs-caption-marker" src="${esc(resource(asset.path))}" alt="" aria-hidden="true" loading="lazy">` : "";
  }
  function platformTitleNote(issue) {
    return issue.platformTitle && issue.platformTitle.trim() !== String(issue.title || "").trim() ? `<p class="qs-platform-title">公众号原标题：《${esc(issue.platformTitle)}》</p>` : "";
  }
  function publicationNote(issue) {
    const publisher = issue.accountName || issue.publisher;
    const publisherLabel = typeof publisher === "string" ? publisher : publisher?.name || text(publisher);
    const parts = [issue.publishedAt ? `公众号发布日期：${issue.publishedAt}（非田野发生日期）` : "", publisherLabel ? `发布账号：${publisherLabel}` : ""].filter(Boolean);
    return parts.length ? `<p class="qs-publication">${parts.map(esc).join(" · ")}</p>` : "";
  }
  function cardTranscript(image) {
    const cardText = image.cardText || assetFor(image)?.cardText;
    if (!cardText) return "";
    return `<div class="qs-card-transcript"><p class="qs-card-transcript-label">图文卡文字转录</p><div>${paragraphs(cardText)}</div></div>`;
  }
  function sourceReferences(issue, paragraphIds) {
    const original=resource(issue.originalPath);
    return paragraphIds.map(value=>{
      const match=String(value).match(/\d+/), number=match ? match[0] : "";
      return original && number ? `<a href="${esc(original+"#source-p-"+number)}" class="qs-source-reference">p${esc(number)}</a>` : esc(value);
    }).join(" / ");
  }
  function figure(photo, issue, index, compact=false) {
    const src = resource(photo.path);
    if(!src) return "";
    const caption = photo.originalCaption || "原文未附独立图注";
    const label = photo.assetId || photo.id || "";
    const size = Number(photo.width) > 0 && Number(photo.height) > 0 ? ` width="${Number(photo.width)}" height="${Number(photo.height)}"` : "";
    return `<figure class="qs-figure${compact ? " qs-figure-compact" : ""}" data-asset-type="${esc(imageType(photo))}" id="qs-${esc(issue.id)}-${compact ? "gallery" : "opening"}-photo-${index + 1}"><a href="${esc(src)}" target="_blank" rel="noopener" aria-label="打开第${index + 1}幅完整图片"><img src="${esc(src)}" alt="${esc(photo.description || photo.originalCaption || "文章配图，详细说明待核对")}"${size} loading="lazy" decoding="async"></a><figcaption><span class="qs-image-type">${esc(typeName(imageType(photo)))}</span><p>${captionMarker(issue)}${esc(caption)}</p><span class="qs-image-meta">${esc(label)}${photo.sourceOrder !== undefined ? ` · 原文位置 ${esc(photo.sourceOrder)}` : ""}</span>${cardTranscript(photo)}</figcaption></figure>`;
  }
  function sectionHead(number, title, sub="") {
    return `<div class="qs-section-head"><span class="qs-section-number">${esc(number)}</span><div><h2>${esc(title)}</h2>${sub ? `<p>${esc(sub)}</p>` : ""}</div></div>`;
  }
  function issueCard(issue) {
    const photo = read(issue) ? ((issue.photos || []).find(image => imageType(image) !== "composite-text-card") || (issue.photos || [])[0]) : null;
    const cover = photo && resource(photo.path) ? `<div class="qs-card-image"><img src="${esc(resource(photo.path))}" alt="${esc(photo.description || photo.originalCaption || "本期配图")}" loading="lazy"${Number(photo.width) && Number(photo.height) ? ` width="${Number(photo.width)}" height="${Number(photo.height)}"` : ""}></div>` : `<div class="qs-card-await"><span>${esc(issue.id)}</span><p>全文与图像<br>等待来源补齐</p></div>`;
    return `<article class="qs-issue-card"><a href="#qingshang/${esc(issue.id)}" class="qs-card-main">${cover}<div class="qs-card-top"><span>ISSUE ${esc(issue.id)}</span><span class="qs-status${read(issue) ? " is-read" : ""}">${read(issue) ? "已读取来源" : "来源待补"}</span></div><h2>${esc(issue.title)}</h2>${platformTitleNote(issue)}${publicationNote(issue)}<p>${read(issue) ? esc(issue.summary || "已取得来源，作品集介绍正在按材料核对。") : "完整来源暂不可读取。本页保留入口与缺项，不依据简介代写摘要。"}</p><span class="qs-card-action">${read(issue) ? "阅读作品与材料" : "查看来源状态"} <span aria-hidden="true">↗</span></span></a></article>`;
  }
  function renderIndex() {
    const all = issues(), completed = all.filter(read), images = completed.flatMap(issue => issue.photos || []), fieldCount = images.filter(isFieldImage).length, otherCount = images.length-fieldCount;
    return `<div class="wrap qs-page qs-index"><header class="qs-hero"><span class="eyebrow">QINGSHANG / FIELDWORK & EDITORIAL PRACTICE</span><div class="qs-hero-grid"><h1>从附近、旧物，<br>到水的记忆。</h1><div class="qs-hero-note"><p>把「箐上」放回具体的材料之间。</p><p>这里保留原文与图注，也记录观察、写作、资料整理和 AI 协作各自的位置。作品集介绍可以重写；来源不会被悄悄覆盖。</p></div></div><div class="qs-ledger"><span>${all.length} 期作品</span><span>${completed.length} 期已读取</span>${all.length>completed.length ? `<span>${all.length-completed.length} 期来源待补</span>` : ""}<span>${fieldCount} 个实拍图位</span><span>${otherCount} 个其他正文图位</span></div></header>
      ${data().relationStatus ? `<p class="qs-relation-status">${esc(data().relationStatus)}</p>` : ""}<section class="qs-series" aria-label="三期箐上作品">${all.map(issueCard).join("")}</section>
      <section class="qs-reading-path">${sectionHead("↳", "一起阅读，也分别核实", "专题联系是阅读的线索，不替代每一期自己的材料。")}<div class="qs-path-columns"><div><span>01 / MATERIAL</span><h3>原文与图像</h3><p>文章、图注与素材位置分别保留。实拍、地图、器物、图文卡与装饰设计不会混算。</p></div><div><span>02 / PRACTICE</span><h3>实践与写作</h3><p>具体判断回到对应材料，区分观察、口述、资料、作者解释与文学引文。</p></div><div><span>03 / PROCESS</span><h3>人与 AI</h3><p>只记录可以确认的整理、叙事或视觉工作。不能确认的分工，保留为待核对事项。</p></div></div></section>
      <section class="qs-index-bottom"><div><span class="eyebrow">AN INDEX, NOT AN ILLUSTRATION POOL</span><h2>每幅图像，<br>保留自己的来处。</h2><p>以素材文件和原文使用位置两种方式建立索引。同一图像重复出现时，仍保留每一次图注与所属篇章。</p></div><div>${link("#qingshang/images", "打开图片索引", "text-link")}<p class="qs-small">索引保留已取得的原图与使用记录。<br>照片、地图、器物和文字卡分别标明用途。</p></div></section>
      <section class="qs-review-notes">${sectionHead("?", "仍需核对与补充")}<div>${list(data().checks, "当前未列出额外核对项；各期局限仍单独保留。")}</div></section></div>`;
  }
  function renderIssue(id) {
    const issue=issues().find(item=>item.id===id);
    if(!issue) return `<div class="wrap qs-page qs-not-found"><h1>尚未收录这一期。</h1>${link("#qingshang","返回箐上专题","text-link")}</div>`;
    const all=issues(), position=all.indexOf(issue), before=all[position-1], after=all[position+1], photos=issue.photos || [];
    const adjacent = `<nav class="qs-adjacent" aria-label="前后期">${before ? link("#qingshang/"+before.id,"← "+before.title) : link("#qingshang","← 专题入口")}${after ? link("#qingshang/"+after.id,after.title+" →") : link("#qingshang","回到专题 →")}</nav>`;
    const head=`<div class="qs-breadcrumb"><a href="#qingshang">← 箐上专题</a><span>ISSUE ${esc(issue.id)}</span></div><header class="qs-issue-header"><div class="qs-issue-kicker"><span>${esc(issue.kicker || "QINGSHANG / FIELD NOTES")}</span><span class="qs-status${read(issue) ? " is-read" : ""}">${read(issue) ? "已读取来源" : "来源待补"}</span></div><h1>${esc(issue.title)}</h1>${platformTitleNote(issue)}${publicationNote(issue)}${read(issue) && issue.summary ? `<p class="qs-issue-deck">${esc(issue.summary)}</p>` : ""}<div class="qs-edition"><span>${esc(issue.version || "版本待确认")}</span><span>原文与作品集解读分开存放</span></div></header>`;
    if(!read(issue)) return `<article class="wrap qs-page">${head}<section class="qs-unavailable"><div class="qs-unavailable-index">${esc(issue.id)}</div><div><h2>先保留入口，<br>等待完整材料。</h2><p>这一期的完整正文、图片和图注尚未取得，因此这里暂不提供内容摘要、图像判断或 AI 分工结论。后续补入来源时会按实际版本核对。</p>${sourceLinks(issue)}<h3>当前缺项</h3>${list(issue.limits,"完整图文 HTML 与内嵌图片、原图注及制作过程依据待提供。")}</div></section>${adjacent}</article>`;
    const sections=issue.sections || [];
    return `<article class="wrap qs-page qs-issue">${head}<nav class="qs-jump-nav" aria-label="本期内容"><a href="#" data-scroll="qs-material-reading">作品集解读</a><a href="#" data-scroll="qs-practice">实践与协作</a><a href="#" data-scroll="qs-gallery">图集与原图注</a><a href="#" data-scroll="qs-original">完整原文</a></nav>
      ${photos.length ? `<div class="qs-opening-image">${figure(photos[0],issue,0)}</div>` : ""}
      <section class="qs-question" id="qs-material-reading"><span class="eyebrow">THE QUESTION / 作品集解读</span><h2>${esc(issue.question || "从具体材料继续追问")}</h2><p class="qs-small">以下是依据本轮取得材料整理的作品集介绍；完整原文另行归档。</p></section>
      <div class="qs-interpretation">${sections.map((entry,index)=>`<section class="qs-reading-section"><div class="qs-margin"><span>${ordinal(index+1,issue)}</span>${entry.kind ? `<span class="qs-evidence-kind">${esc(entry.kind)}</span>` : ""}</div><div class="qs-reading-copy"><h2>${esc(entry.title)}</h2>${paragraphs(entry.text)}${(entry.sourceParagraphIds || []).length ? `<p class="qs-source-ids">来源段落：${sourceReferences(issue,entry.sourceParagraphIds)}</p>` : ""}</div></section>`).join("")}</div>
      <section class="qs-practice" id="qs-practice">${sectionHead("↳", "实践、写作与协作", "让贡献回到可确认的工作，而不是把整个田野标为 AI 生成。")}<div class="qs-process-grid"><section><span class="qs-process-label">METHODS</span><h3>怎样观察与整理</h3>${list(issue.methods)}</section><section><span class="qs-process-label">AUTHOR'S PRACTICE</span><h3>我的参与与写作</h3>${list(issue.contribution,"个人分工未有充分制作记录，待作者确认。")}</section><section><span class="qs-process-label">AI / HUMAN JUDGEMENT</span><h3>AI 的参与边界</h3>${list(issue.ai,"尚无可确认的 AI 制作记录，暂不归因。")}</section></div></section>
      <section class="qs-gallery" id="qs-gallery">${sectionHead("▧", "正文配图与原图注", `${photos.length} 个正文图位：${imageCounts(photos)}。按正文顺序展示，点击图片可查看完整画幅。`)}<div class="qs-gallery-grid">${photos.map((photo,index)=>figure(photo,issue,index,true)).join("")}</div>${link("#qingshang/images", "在图片索引中查看素材类别与使用关系")}</section>
      <section class="qs-original" id="qs-original"><span class="eyebrow">RETURN TO THE SOURCE</span><div><h2>回到完整原文。</h2><p>作品集介绍是一次整理。原文、图注和既有版本仍保留在独立档案中，供继续阅读与核查。</p>${sourceLinks(issue)}</div></section>
      <section class="qs-limits">${sectionHead("?", "材料的边界，与下次要问的问题")}<div>${list(issue.limits)}</div></section>${adjacent}</article>`;
  }
  function renderImages() {
    const all=data().assets || [], occurrences=data().occurrences || [];
    const type=new URLSearchParams(location.hash.split("?")[1] || "").get("type") || "";
    const types=[...new Set(all.map(typeOf))];
    const selected=type ? all.filter(asset=>typeOf(asset)===type) : all;
    return `<div class="wrap qs-page qs-image-index"><div class="qs-breadcrumb"><a href="#qingshang">← 箐上专题</a><span>ASSETS / OCCURRENCES</span></div><header class="qs-image-header"><span class="eyebrow">A SOURCE-AWARE IMAGE INDEX</span><h1>图像各有来处。</h1><p>${all.length} 个已取得素材文件，${occurrences.length} 条原文使用记录。按哈希去重文件，同时保留不同篇章、位置与视觉版本的使用关系。</p><p class="qs-small">按素材文件统计：${types.map(kind=>`${typeName(kind)} ${all.filter(asset=>typeOf(asset)===kind).length} 个`).map(esc).join(" · ")}。同一标识的不同格式文件与其原文使用次数分别记录。</p></header><nav class="qs-type-filter" aria-label="图片类型筛选">${link("#qingshang/images","全部素材",type ? "qs-type-option" : "qs-type-option is-selected")}${types.map(value=>link("#qingshang/images?type="+encodeURIComponent(value),typeName(value),type===value ? "qs-type-option is-selected" : "qs-type-option")).join("")}</nav><p class="qs-result-count">${selected.length} / ${all.length} 个素材</p><div class="qs-assets-grid">${selected.map((asset,index)=>{
      const id=asset.assetId || asset.id || "", path=asset.path || asset.file || asset.localPath || "", src=resource(path), uses=occurrences.filter(item=>item.assetId===id || item.asset_id===id);
      const sourceIssues=[...new Set(uses.map(item=>item.issueId || item.articleId || item.issue || "").filter(Boolean))], unused=asset.usageStatus==="source-alternate-unused";
      const transcript = asset.cardText || issues().flatMap(issue=>issue.photos || []).find(image=>(image.assetId || image.id)===id && image.cardText)?.cardText;
      return `<article class="qs-asset-card"><div class="qs-asset-visual">${src ? `<a href="${esc(src)}" target="_blank" rel="noopener"><img src="${esc(src)}" alt="${esc(asset.description || asset.originalDescription || asset.originalCaption || typeName(typeOf(asset)))}" loading="lazy"${Number(asset.width) && Number(asset.height) ? ` width="${Number(asset.width)}" height="${Number(asset.height)}"` : ""}></a>` : '<p>素材地址待补</p>'}</div><div class="qs-asset-label"><span>${esc(typeName(typeOf(asset)))}</span><span>${unused ? "已归档备选" : `${uses.length} 次使用`}</span></div><h2>${esc(asset.title || asset.originalDescription || asset.description || id || `素材 ${index+1}`)}</h2><p class="qs-asset-id">${esc(id)}</p>${asset.sha256 || asset.hash ? `<p class="qs-hash">SHA-256 / ${esc(asset.sha256 || asset.hash)}</p>` : ""}${Number(asset.width) && Number(asset.height) ? `<p class="qs-small">${Number(asset.width)} × ${Number(asset.height)} px</p>` : ""}${transcript ? cardTranscript({...asset,cardText:transcript}) : ""}<details class="qs-occurrence"><summary>原文位置与图注</summary>${uses.length ? uses.map(use=>`<div><p class="qs-small">${esc(use.issueId || use.articleId || use.issue || "")} · ${esc(use.variant || use.sourceVersion || "原文")} · 位置 ${esc(use.sourceOrder ?? use.position ?? "无固定图位")}</p><p>${esc(use.originalCaption || use.caption || "此位置未附独立图注")}</p>${use.intendedUse || use.use ? `<p class="qs-small">用途：${esc(use.intendedUse || use.use)}</p>` : ""}</div>`).join("") : unused ? '<p>原始来源中的备选文件；当前已收录正文未引用。</p>' : '<p>使用关系待补齐。</p>'}</details><div class="qs-asset-issues">${sourceIssues.map(issueId=>link("#qingshang/"+issueId, "第 "+issueId+" 期")).join("")}</div></article>`;
    }).join("")}</div>${all.length ? "" : '<div class="qs-unavailable"><p>尚未取得可索引的图像文件，不以示意图补足数量。</p></div>'}</div>`;
  }
  root.Qingshang={renderIndex,renderIssue,renderImages};
})(window);
