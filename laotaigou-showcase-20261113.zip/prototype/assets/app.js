(() => {
  "use strict";
  const D = window.LTG_DEMO, C = window.ArchiveCore;
  const resourceRoot = document.body.dataset.resourceRoot || "../";
  const media = window.LTG_MEDIA?.assets || [];
  const photoAssets = media.filter(asset => asset.type === "field-photograph");
  const themes = ["行走", "共同在场", "手艺", "劳动", "儿童观察", "村庄景观", "共同在场", "行走"];
  const photoItems = photoAssets.map((asset, index) => ({
    id: asset.id, type: "Photograph", title: asset.title, year: "", date: "拍摄日期待核对",
    place: "地点待核对", person: "", theme: themes[index], trip: "补充照片 · 2026-11-11收录",
    format: "photo", text: asset.caption, source: "用户提供的补充照片；摄影署名与对外公开授权待补充。",
    asset, real: true
  }));
  const items = [...photoItems, ...D.items];
  const main = document.getElementById("main"), dialog = document.getElementById("item-dialog");
  const originalStrip = document.querySelector(".review-strip").innerHTML;
  const originalFooterNote = document.querySelector(".site-footer .small").innerHTML;
  let state = {}, previousTrigger = null, toastTimer;
  const esc = value => String(value ?? "").replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
  const label = type => D.typeLabels[type] || type;
  const hashFor = values => C.stateHash(values);
  function photo(id, className = "", eager = false) {
    const asset = media.find(entry => entry.id === id);
    return asset ? `<img class="field-photo ${esc(className)}" src="${esc(resourceRoot + asset.path)}" width="${asset.width}" height="${asset.height}" alt="${esc(asset.caption)}" loading="${eager ? "eager" : "lazy"}" decoding="async">` : "";
  }
  function photoFigure(id, className = "") {
    const asset = media.find(entry => entry.id === id);
    if (!asset) return "";
    return `<figure class="${esc(className)}"><a href="${hashFor({item:id})}" data-item="${id}" aria-label="查看${esc(asset.title)}的照片与来源">${photo(id)}</a><figcaption><span>△ ${esc(asset.caption)}</span><span>${id.toUpperCase()}</span></figcaption></figure>`;
  }
  function thumb(item) {
    if (item.real) return `<div class="photo-thumb thumb">${photo(item.id)}</div>`;
    if (item.format === "text") return `<div class="placeholder thumb text" aria-hidden="true"><div class="paper-preview">${esc(item.text.slice(0, 48))}……</div></div>`;
    if (item.format === "audio") return `<div class="placeholder thumb" aria-hidden="true"><div class="audio-mark">声音<small>AUDIO NOT PROVIDED</small></div></div>`;
    return `<div class="placeholder thumb ${esc(item.format)}" aria-hidden="true"><div class="thumb-title">${item.format === "map" ? "地点关系" : item.type === "Student Work" ? "作品待收录" : "影像待入档"}<span>${item.format === "map" ? "SCHEMATIC / DEMO" : "NEUTRAL PLACEHOLDER"}</span></div></div>`;
  }
  function itemLink(item, text, className = "text-link", filters = {}) {
    return `<a class="${className}" href="${esc(hashFor({...filters, item: item.id}))}">${esc(text)} <span aria-hidden="true">↗</span></a>`;
  }
  function card(item, filters = {}) {
    return `<a class="archive-card" data-item="${esc(item.id)}" href="${esc(hashFor({...filters, item: item.id}))}" aria-label="${esc(item.title)}，${label(item.type)}，${item.real ? "补充实拍" : "演示条目"}">${thumb(item)}<div class="id">${esc(item.id)}</div><h3>${esc(item.title)}</h3><div class="card-bottom"><span>${label(item.type)} · ${item.real ? "实拍" : "演示"}</span><span>${item.real ? "日期待核对" : esc(item.year)} / ${esc(item.theme)}</span></div></a>`;
  }
  function section(index, title, english, right = "") {
    return `<div class="section-head"><h2 class="section-label"><span class="meta">${index}</span>${title}</h2>${right || `<span class="meta muted">${english}</span>`}</div>`;
  }
  function home() {
    return `<div class="wrap home-page">
      <div class="intro-line meta"><span>FIELD ARCHIVE<br>DALI, YUNNAN · 中国云南大理</span><span>一个持续生长的地方档案<br>PUBLIC SPACE / PEOPLE / MEMORY</span></div>
      <section class="home-masthead"><h1>老太沟<span class="latin">LAOTAIGOU</span></h1><div class="home-intro"><h2>把一个地方，<br>慢慢读懂。</h2><p>关于一座书苑、周围的村庄，<br>以及在这里发生的相遇与日常。</p></div></section>
      <figure class="home-field-hero">${photo("field-01", "", true)}<figcaption><span>△ 一行人走在绿树环绕的村路上。</span><span>用户提供 · 实拍</span></figcaption></figure>
      <div class="home-lead"><p>从一座书苑出发，<br>记录人与地方如何彼此塑造。</p><div class="side-note">这是一个关于云南大理老太沟书苑及周边村庄的长期田野项目。照片、交谈、手记和地图，将在这里被整理，也在新的相遇中不断被重新理解。<br><a class="text-link" href="#archive">从档案开始探索 <span aria-hidden="true">↗</span></a></div></div>
      <section class="qs-home-entry"><div>${photo("qingshang-wordmark", "qs-wordmark")}<span class="eyebrow">QINGSHANG / A CONNECTED SERIES</span><h2>从附近、旧物，<br>到水的记忆。</h2></div><div><p>把「箐上」三期写作，与原文、配图和制作过程放在一起阅读。从附近的生活、旧布上的花，到沿水路的行走，每一期都可以返回具体材料。</p><a class="text-link" href="#qingshang">进入箐上专题 <span aria-hidden="true">↗</span></a></div></section>
      <section class="field-gallery-section">${section("01", "在场的片段", "FIELD PHOTOGRAPHS", `<a class="text-link" href="${hashFor({type:"Photograph"})}">照片档案 ↗</a>`)}<div class="field-gallery">${photoAssets.slice(1).map(asset => photoFigure(asset.id)).join("")}</div><p class="small gallery-note">本次补充的实拍照片。图注只描述可见内容；拍摄日期、摄影署名与人物公开范围仍待补充。</p></section>
      <section class="note-preview home-note">${section("02", "最近的田野手记", "FIELD NOTE")}<span class="meta muted">FIELD NOTE / DEMO</span><h3>从一个问题开始</h3><p>如何把一次观察，变成可以被再次阅读、比较与追问的田野记录？这一位置将呈现最近一次田野中的思考。</p>${itemLink(D.items[0], "打开手记结构")}</section>
      <section>${section("03", "人物与声音", "PEOPLE / VOICES")}<div class="person-feature">${photoFigure("field-07", "people-context-photo")}<div><span class="eyebrow accent">A PERSON, A POINT OF CONNECTION</span><h3>认识一个人，<br>也认识一种在地的知识。</h3><p>人物不只是简介。他们的交谈、行动、记忆，以及与书苑和村庄的关系，将把不同材料连接起来。</p><a class="text-link" href="#person">查看人物档案结构（演示） <span aria-hidden="true">↗</span></a></div></div></section>
      <section class="home-archive">${section("04", "从资料出发", "FROM THE ARCHIVE", `<a class="text-link" href="#archive">浏览 ${items.length} 条资料 <span aria-hidden="true">↗</span></a>`)}<div class="archive-grid">${[photoItems[2], D.items[0], D.items[1], D.items[3]].map(item => card(item)).join("")}</div></section>
      <div class="home-context"><section>${section("05", "地方之间", "PLACES")}<div class="map-sketch"><span class="meta muted">SPATIAL RELATION / DEMO</span><div class="map-links"><a class="map-node" href="${esc(hashFor({place: "书苑（演示）"}))}">书苑</a><span class="map-line"></span><a class="map-node" href="${esc(hashFor({place: "村庄公共道路（演示）"}))}">道路</a><span class="map-line"></span><a class="map-node" href="${esc(hashFor({place: "水源地点（演示）"}))}">水源</a></div><p class="small">仅演示地点关系，无真实坐标、距离与方位。</p></div></section>
      <section>${section("06", "三条时间", "PARALLEL HISTORIES")}<div class="timeline-mini"><div class="track"><span>村庄</span><p>地方记忆与村庄变化<br><span class="small">事件与日期等待核实</span></p></div><div class="track"><span>书苑</span><p>公共文化空间的生成与延续<br><span class="small">发展节点等待整理</span></p></div><div class="track"><span>田野</span><p>研究者的进入、返回与认识变化<br><span class="small">田野批次结构已预留</span></p></div></div></section></div>
      <section class="research-band"><div><span class="eyebrow accent">CURRENT RESEARCH</span><p>一个正在推进的问题<br>工作题目，来自项目说明</p></div><div><h2>乡村公共文化空间<br>如何生成、扎根与再生产？</h2><p>《从“无用”到“可持续”：乡村公共文化空间的生成、扎根与再生产——以大理老太沟书苑为例》</p><a class="text-link" href="#archive">沿着资料，继续追问 <span aria-hidden="true">↗</span></a></div></section>
    </div>`;
  }
  function facet(key, title) {
    const options = key === "type" ? D.types : [...new Set(items.map(item => item[key]).filter(Boolean))].sort();
    return `<label>${title}<select name="${key}" aria-label="筛选${title}"><option value="">全部${title}</option>${options.map(value => `<option value="${esc(value)}" ${state[key] === value ? "selected" : ""}>${esc(key === "type" ? label(value) : value)}</option>`).join("")}</select></label>`;
  }
  function archive() {
    return `<div class="wrap archive-page"><div class="page-title"><span class="eyebrow accent">THE RESEARCH ARCHIVE</span><div class="title-row"><h1>研究档案</h1><p>资料有出处，记录有来处。<br>沿着人、地方、主题与时间查找材料。<br><span class="small">${photoItems.length} 张补充实拍与 ${D.items.length} 条演示资料；三期原文另见箐上专题。</span></p></div></div>
      <label class="search-field"><span>SEARCH THE ARCHIVE / 照片与资料检索</span><input type="search" id="archive-search" value="${esc(state.q)}" placeholder="搜索标题、主题或 Archive ID" autocomplete="off"></label>
      <details class="filters" ${matchMedia("(min-width: 768px)").matches ? "open" : ""}><summary>筛选资料 · 类型 / 年份 / 人物 / 地点 / 主题 / 田野</summary><div class="filter-grid">${facet("type", "类型")}${facet("year", "年份")}${facet("person", "人物")}${facet("place", "地点")}${facet("theme", "主题")}${facet("trip", "田野")}</div></details>
      <div class="archive-tools"><div><span id="result-count" role="status" aria-live="polite"></span> <button class="reset" data-action="reset">清除条件</button></div><div class="right-tools"><label>排序 <select id="sort" aria-label="资料排序"><option value="">年份：新 → 旧</option><option value="oldest" ${state.sort === "oldest" ? "selected" : ""}>年份：旧 → 新</option><option value="title" ${state.sort === "title" ? "selected" : ""}>标题顺序</option></select></label><div class="view-toggle" role="group" aria-label="显示方式"><button data-view="grid" aria-pressed="${state.view !== "list"}">网格</button><button data-view="list" aria-pressed="${state.view === "list"}">列表</button></div></div></div>
      <div id="active-filters" class="active-filters" aria-label="已选筛选条件"></div><div id="archive-results" tabindex="-1"></div>
      <p class="demo-note" style="margin-top:45px">实拍照片与演示条目分别标注。演示条目的年月、人物与访谈不作为田野事实。<br>本地预览没有文件上传服务。录音和文档尚未导入；对外发布需另行确认相应授权。</p></div>`;
  }
  function person() {
    const personItems = D.items.filter(item => item.person);
    return `<article class="wrap"><div class="breadcrumb"><a href="#home">← 在地阅读 / 人物与声音</a><span class="meta">PERSON / DEMO</span></div>
      <header class="person-header"><div class="person-intro-panel"><span class="eyebrow">PEOPLE / VOICES</span><p>在交谈中，<br>理解一个地方。</p><span class="small">人物档案结构演示<br>姓名、肖像与访谈将在取得相应授权后收录。</span></div><div class="person-dossier"><span class="eyebrow accent">A PERSON IN THE ARCHIVE</span><h1>${D.person.name}</h1><p class="meta muted">${D.person.id}</p><p class="description" style="margin-top:25px">${D.person.description}</p><p class="demo-note">这是一个合成人物节点。<br>没有代指某位真实受访者。</p><dl class="metadata"><dt>与老太沟</dt><dd>关系描述待真实资料</dd><dt>角色</dt><dd>演示标签，不作身份认定</dd><dt>首次相遇</dt><dd>待录入 / 支持不确定日期</dd><dt>公开范围</dt><dd>本页只有合成示例</dd><dt>资料修订</dt><dd>随授权与研究核实更新</dd></dl></div></header>
      <section>${section("01", "声音与访谈", "VOICES")}<div class="voice-block"><div class="voice-intro"><h2>在交谈中，<br>理解一个地方。</h2><p class="caption">访谈可以从摘要进入，也可以沿着主题和时间段阅读转写。</p></div><div class="voice-panel"><span class="meta accent">INTERVIEW / DEMO</span><h3>与一位参与者的对话</h3><p>未来呈现：访谈摘要、地点、访谈者、授权后的音频与转写，以及可定位的时间段。</p><div class="voice-status"><span class="audio-mark" aria-hidden="true">声音</span><p>音频尚未提供<br><span class="small">此处为组件位置，不提供模拟播放。</span></p></div><p class="small">主题结构：公共空间 / 教育 / 可持续性<br>时间码与主题将关联到经审核的公开节选。</p>${itemLink(D.items[1], "查看访谈条目")}</div></div></section>
      <section class="person-materials">${section("02", "围绕这个人物的资料", "RELATED MATERIALS", `<a class="text-link" href="${esc(hashFor({person: "一位书苑参与者（演示）"}))}">在档案中筛选 <span aria-hidden="true">↗</span></a>`)}<div class="archive-grid">${personItems.slice(0, 4).map(item => card(item)).join("")}</div></section>
      <div class="relations"><section class="relation-group"><h3>关联地点 / PLACE</h3><a href="${esc(hashFor({place: "书苑（演示）"}))}">书苑 ↗</a><p class="small">检索该地点的资料</p></section><section class="relation-group"><h3>相关主题 / THEME</h3><a href="${esc(hashFor({theme: "公共空间"}))}">公共空间 ↗</a><p class="small">关系是继续阅读的入口</p></section></div><div class="share-area"><button class="text-link" data-action="share">复制本页预览地址 <span aria-hidden="true">↗</span></button><div id="share-fallback"></div></div></article>`;
  }
  function refreshResults() {
    const results = C.filterItems(items, state);
    document.getElementById("result-count").textContent = `${String(results.length).padStart(2, "0")} 条结果`;
    document.getElementById("archive-results").innerHTML = results.length ? `<div class="${state.view === "list" ? "archive-list" : "archive-grid"}">${results.map(item => card(item, {...state, item: ""})).join("")}</div>` : `<div class="empty"><h2>还没有符合条件的资料。</h2><p>试着放宽一个条件，或清除筛选，继续从别处进入。</p><button class="text-link" data-action="reset">清除全部条件 ↗</button></div>`;
    const names = {type: "类型", year: "年份", person: "人物", place: "地点", theme: "主题", trip: "田野", q: "搜索"};
    document.getElementById("active-filters").innerHTML = [...C.facets, "q"].filter(key => state[key]).map(key => `<button class="filter-chip" data-clear="${key}" aria-label="清除${names[key]}条件">${names[key]}：${esc(key === "type" ? label(state[key]) : state[key])} ×</button>`).join("");
    document.querySelectorAll("[data-view]").forEach(button => button.setAttribute("aria-pressed", button.dataset.view === state.view));
  }
  function updateState(values) {
    state = {...state, ...values, item: ""};
    history.replaceState(null, "", C.stateHash(state));
    refreshResults();
  }
  function showItem(id) {
    const item = items.find(item => item.id === id);
    if (!item) { toast("没有这个条目，请从档案重新选择。"); return; }
    const matches = item.asset?.existingMatches || [];
    const sourceLinks = matches.map(match => `<a class="text-link" href="#qingshang/${match.sourceId.includes("003-V05") ? "03" : "01"}">同幅照片所在文章 ↗</a>`).join("");
    const photoMetadata = item.real ? `<dt>图注性质</dt><dd>作品集整理图注，描述可见内容</dd><dt>署名与公开</dt><dd>摄影者、具体人物与未成年人公开授权范围待核对</dd><dt>展示文件</dt><dd>压缩展示副本，保持比例，无裁切；未写入 EXIF</dd>${matches.length ? `<dt>原有材料关系</dt><dd>${matches.some(match => match.relation === "byte-identical") ? "原附件与已归档素材字节相同" : "与已归档照片为同幅影像的不同文件版本"}；保留两次提供的来源记录。</dd>` : ""}` : "";
    document.getElementById("dialog-content").innerHTML = `<div class="dialog-top"><span class="meta accent">${esc(item.id)}</span><button data-action="close-dialog" autofocus aria-label="关闭条目详情">关闭 ×</button></div><h2 id="dialog-title">${esc(item.title)}</h2>${thumb(item)}<p class="demo-note">${label(item.type)} · ${item.real ? "用户提供的实拍照片" : "演示条目，无真实田野材料"}</p><p>${esc(item.text)}</p><dl class="metadata"><dt>日期</dt><dd>${esc(item.date)}</dd><dt>地点</dt><dd>${esc(item.place)}</dd><dt>主题</dt><dd>${esc(item.theme)}</dd><dt>${item.real ? "收录批次" : "田野批次"}</dt><dd>${esc(item.trip)}</dd><dt>来源与状态</dt><dd>${esc(item.source)}</dd>${photoMetadata}</dl><div class="dialog-related">${item.person ? `<a class="text-link" href="#person">关联人物 ↗</a>` : ""}${sourceLinks}<a class="text-link" href="${esc(hashFor({theme: item.theme}))}">同主题资料 ↗</a></div>`;
    if (!dialog.open) dialog.showModal();
  }
  function closeItem() {
    state.item = "";
    history.replaceState(null, "", C.stateHash(state));
    dialog.close();
    const trigger = previousTrigger && document.querySelector(`[data-item="${previousTrigger}"]`);
    (trigger || document.getElementById("archive-results"))?.focus({preventScroll:true});
  }
  function toast(message) {
    const box = document.getElementById("toast");
    clearTimeout(toastTimer); box.textContent = message; box.classList.add("visible");
    toastTimer = setTimeout(() => box.classList.remove("visible"), 3000);
  }
  function render(initial = false) {
    const hash = location.hash || "#" + (document.body.dataset.defaultRoute || "home");
    const path = hash.slice(1).split("?")[0];
    const [page, issueId] = path.split("/");
    if (dialog.open) dialog.close();
    state = C.parseState(hash);
    const pages = {home, archive, person};
    const isQingshang = page === "qingshang";
    document.body.dataset.section = isQingshang ? "qingshang" : page;
    document.querySelector(".review-strip").innerHTML = isQingshang ? '<span>箐上 · 田野、写作与材料</span><span>原文与作品集解读分开保存</span>' : originalStrip;
    document.querySelector(".site-footer .small").innerHTML = originalFooterNote;
    if (isQingshang && window.Qingshang) main.innerHTML = issueId === "images" ? window.Qingshang.renderImages() : issueId ? window.Qingshang.renderIssue(issueId) : window.Qingshang.renderIndex();
    else main.innerHTML = pages[page] && !issueId ? pages[page]() : `<div class="wrap" style="padding-block:80px"><h1>这个视图还未建立。</h1><a class="text-link" href="#home">返回首页 ↗</a></div>`;
    document.querySelectorAll("[data-nav]").forEach(a => { if(a.dataset.nav === page) a.setAttribute("aria-current", "page"); else a.removeAttribute("aria-current"); });
    const titles = {home:"老太沟 · 数字田野档案", archive:"研究档案 · 老太沟", person:"人物与声音 · 档案演示"};
    const issue = window.QS_DATA?.issues?.find(item => item.id === issueId);
    document.title = isQingshang ? (issueId === "images" ? "图片索引 · 箐上专题" : issue ? `${issue.title} · 箐上专题` : "从附近、旧物到水的记忆 · 箐上专题") : titles[page] || "视图未建立 · 老太沟";
    if (page === "archive") { refreshResults(); if(state.item) showItem(state.item); }
    if(!initial && (page !== "archive" || !state.item)) { main.focus({preventScroll: true}); window.scrollTo({top:0, behavior:"instant"}); }
  }
  document.addEventListener("input", event => { if(event.target.id === "archive-search") updateState({q: event.target.value}); });
  document.addEventListener("change", event => {
    if (C.facets.includes(event.target.name)) updateState({[event.target.name]: event.target.value});
    if (event.target.id === "sort") updateState({sort:event.target.value});
  });
  document.addEventListener("click", async event => {
    const link = event.target.closest("a");
    if (link?.classList.contains("skip")) { event.preventDefault(); main.focus(); return; }
    if (link?.dataset.scroll) { event.preventDefault(); document.getElementById(link.dataset.scroll)?.scrollIntoView(); return; }
    if (link?.dataset.item) previousTrigger = link.dataset.item;
    const view = event.target.closest("[data-view]");
    if(view) updateState({view:view.dataset.view});
    const clear = event.target.closest("[data-clear]");
    if(clear) { const key=clear.dataset.clear; updateState({[key]:""}); if(key === "q") document.getElementById("archive-search").value=""; else document.querySelector(`[name="${key}"]`).value=""; document.getElementById("archive-search").focus(); }
    const action = event.target.closest("[data-action]")?.dataset.action;
    if(action === "reset") { const viewValue = state.view; state = {view: viewValue}; history.replaceState(null,"", C.stateHash(state)); render(); }
    if(action === "close-dialog") closeItem();
    if(action === "share") {
      try { if (!navigator.clipboard) throw new Error("manual"); await navigator.clipboard.writeText(location.href); toast("已复制本机预览地址"); }
      catch { const fallback = document.getElementById("share-fallback"); fallback.innerHTML=`<label class="small">本机预览地址，可手动复制（正式站使用公开稳定链接）<br><input readonly aria-label="本页预览地址" value="${esc(location.href)}"></label>`; fallback.querySelector("input").select(); }
    }
  });
  dialog.addEventListener("cancel", event => { event.preventDefault(); closeItem(); });
  dialog.addEventListener("keydown", event => {
    if (event.key !== "Tab") return;
    const controls = [...dialog.querySelectorAll("button:not([disabled]), a[href], input:not([disabled]), select:not([disabled]), [tabindex='0']")];
    const first = controls[0], last = controls.at(-1);
    if (event.shiftKey && (document.activeElement === first || document.activeElement === dialog)) { event.preventDefault(); last?.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
  });
  matchMedia("(min-width: 768px)").addEventListener("change", event => {
    const filters = document.querySelector(".filters");
    if (filters && event.matches) filters.open = true;
  });
  window.addEventListener("hashchange", () => render());
  render(true);
})();

