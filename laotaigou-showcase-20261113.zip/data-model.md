# 老太沟数字田野档案 · 数据模型 v0.1

本文件是第一阶段的数据契约与迁移方案。它不声明已经取得任何真实素材、人物授权或访谈记录。所有带 `DEMO-` 的数据均为演示，不能用于论文论证，也不计入正式档案统计。

配套结构文件：`archive.schema.json`，采用 JSON Schema Draft 2020-12。它同时定义私有主档 `kind: master` 与公开派生包 `kind: public`。Schema 验证字段结构；授权有效性、匿名充分性和文件内容仍需发布校验与研究者审核。

## 1. 两个数据域，一套稳定标识

```text
私有主档（不进公开 Git 仓库）
  原始文件 / 私有身份表 / 联系信息 / 授权凭证 / 研究笔记
  canonical metadata + typed relations + consent records
                   │ 人工审核 + 授权 + 脱敏 + 白名单导出
                   ▼
公开派生包（网站唯一内容来源）
  public entities / public relations / approved derivatives / public search index
```

`visibility` 不是前端的显示开关。只在浏览器里过滤敏感记录，会让这些记录仍随 JS、JSON、源映射或搜索索引被下载。网站构建只能读取已经导出的公开包；私有主档、未剪辑录音、原始 EXIF 和授权书均不进入网站源码或构建上下文。

V1 不建复杂账号后台。`private` 和 `research-only` 先保存在受控的本地或机构存储中。以后有认证与服务端授权时，再为研究者提供受限检索；公开站现在不能承担“研究账号访问原始档案”的功能。

## 2. ID、版本与时间

| 对象 | ID 代码 | 示例（均为演示） |
|---|---|---|
| Person / Place / Event / Fieldwork | PN / PL / EV / FW | `DEMO-LTG-PN-2026-001` |
| Photograph / Audio / Video | PH / AU / VD | `DEMO-LTG-PH-2026-001` |
| Transcript / Field Note / Document | TR / FN / DC | `DEMO-LTG-TR-2026-001` |
| Map / Student Work / Research Note / Web Article | MP / SW / RN / WA | `DEMO-LTG-WA-2026-001` |
| Interview / Story / Theme / Collection | IV / ST / TH / CL | `DEMO-LTG-IV-2026-001` |
| Publication / ResearchProject | PB / RP | `DEMO-LTG-PB-2026-001` |
| Asset / Relation / Consent | AS / RL / CS | `DEMO-LTG-AS-2026-001` |

生产标识去掉 `DEMO-`，例如 `LTG-PH-2026-001`。年份是首次编目年，不承诺拍摄或事件发生在该年。年份不确定的历史材料仍可获得稳定 ID；实际发生时间单独记录。ID 一经发出不重用、不随标题、文件名、匿名名或搬迁改变；合并时保留重定向表。路径、slug 与中文标题都不是主键。生产 ID 分配使用独立递增注册表，禁止多人凭文件夹各自编号。

每条记录有 `createdAt` / `updatedAt`（带时区的 ISO 时间），每次公开版有 `releaseId` 和内容哈希 `revisionHash`。引用材料时用实体 ID + 公开版本 + 页段或时间段，避免后来修订导致引文漂移。演示数据的 `isDemo: true` 必须与 `DEMO-` 前缀一致；迁移真实内容时重新编目，不能只删前缀。

`Temporal` 结构：

```json
{
  "label": "约在某年冬季（格式示意，不是田野事实）",
  "precision": "season",
  "start": "2026",
  "certainty": "approximate",
  "sourceIds": []
}
```

`precision` 为 `day / month / year / season / range / unknown`；`certainty` 为 `exact / approximate / uncertain / disputed / unknown`。`start` / `end` 接受 `YYYY`、`YYYY-MM`、`YYYY-MM-DD`，不确定时保留原始口述标签与依据。`unknown` 不填起止值，不用 `1900-01-01`、编目日或任意日期占位；有争议的说法分别记录来源，不强行合并。时间线展示区间或“约”，不把年份自动解释为 1 月 1 日。构建程序还需检查日历合法性、精度与字符串一致、起止顺序。

## 3. 所有主档记录共用的字段

| 字段 | 类型 / 规则 |
|---|---|
| `id`, `entityType`, `title` | 稳定 ID、类型判别、工作标题；必填 |
| `visibility` | `private / research-only / public-anonymous / public`；必填，无默认公开 |
| `status` | `draft / in-review / published / withdrawn`；与权限分开 |
| `isDemo` | 布尔值；必填；公开站显著标出演示 |
| `createdAt`, `updatedAt` | 日期时间；必填 |
| `languages` | BCP 47 语言标签数组，如 `zh-Hans`；方言另记说明 |
| `summary`, `date` | 摘要、结构化时间；可选 |
| `provenance` | 来源类型、说明、来源 ID、采集者、原链接、AI 辅助与人工复核情况 |
| `rights` | 权利状态、权利人、署名、许可与限制；“公开可见”不等于可再发布 |
| `release` | 发布审批状态、审核者、时间、授权 ID、源版本哈希、已审字段、匿名/空间/衍生文件复核、有效期 |

`public` / `public-anonymous` 且 `status: published` 的主档必须有批准的 `release` 和明确可发布的权利状态。即使 Schema 通过，也不代表授权覆盖了所有人物、声音或二次用途。

## 4. 实体字段与基数

### Person · 人物知识节点

`displayName`、`anonymousName`、`roles[]`、`relationshipToLaotaigou`、`subjectAgeClass`、`firstEncounter`、`yearsActive`、`biographyMarkdown`。`privateIdentity` 另存真实姓名、联系信息、监护人关联和私有备注，只存在于主档。

一个 Person 可关联多次 Interview、多张 Photograph、多篇 Story、多处 Place、多次 Event / Fieldwork 和多个 Theme。关联列表由关系索引生成，不把整份访谈嵌进人物对象。角色是多值且可随时间变化；对一个角色有明确任期时，以有时间与证据的 Relation 或 Event 表达。

V1 公开未成年人一律采用匿名派生展示，不提供真名映射；默认不展示可识别人脸、声音、学校班级或家庭位置。公开人物名与匿名名分别人工审核，不能只把姓名字段替换后保留足以识别身份的组合信息。年龄不明按待核实处理，不自动当作成年人。

公开 Person 可保留经过单独审核的 `relationshipToLaotaigou`、`firstEncounter`、`yearsActive`，不将这些研究关系压成一段不可检索的简介。两项时间映射为不含私有 `sourceIds` 的 `publicTemporal`，关系描述也要检查间接识别线索；未经批准的字段省略。

### Place · 空间节点

`placeType`、`descriptionMarkdown`、`parentPlaceId`、私有 `geometry`、另行审批的 `publicGeometry`、`publicSpatialPrecision`、`publicLocationLabel`。

类型包括书苑、居民区、道路、学校、水库、水井、农田、活动地、路线、公共空间等。Geometry 预留 WGS84 GeoJSON 的 Point / LineString / Polygon。一个 Place 可有多个子地点并关联多份材料、访谈、事件与故事；一个材料也可涉及多个地点。

公开空间精度为 `exact-public-place / approximate / area / withheld`。不由精确几何自动降精度后直接发布：模糊点仍可能指向唯一家庭。没有经核实且获准的坐标时，只显示地点名称或“位置待核实”，不伪造经纬度。地图界面第一阶段可用明确标注“不按比例、不代表真实方位”的关系示意图。

`publicSpatialPrecision: withheld` 时，主档与公开包都禁止出现 `publicGeometry`；只要填了 `publicGeometry` 就必须同时声明公开精度。公开 Place 始终声明精度。主档的私有 `geometry` 与公开几何分开：即使公开位置 withheld，也可在受控主档保留真实几何，导出时绝不复制该字段。公开包结构本身不允许私有 `geometry` 字段。

### Event · 三轨时间线节点

`occurredAt`、`track`（`village / learning-place / fieldwork`）、`eventType`、`descriptionMarkdown`。一条事件有一条主轨；跨轨关系通过关联表达，不复制三个事件。时间、参与者与地点均需来源支持。一个事件可关联多名人物、多地、多份证据；历史说法可保留 `disputed` 状态。

### Fieldwork · 一次进入田野

`occurredAt`、`sequence`、`season`、`researchQuestions[]`、`introductionMarkdown`、`reflectionMarkdown`。一个 Fieldwork 关联多份笔记、照片、访谈、事件、人物、地点和 Story；一份材料可关联多个调查批次，例如后续回访重新解释同一照片。私人反思不随公开简介一并导出。

### ArchiveItem · 材料编目层

`materialType`、`descriptionMarkdown`、`caption`、`assetIds[]`、`creatorIds[]`、`fullText`、`languageNotes`、可选 `transcriptOfInterviewId`。

材料种类为 Photograph、Audio、Video、Transcript、Field Note、Document、Map、Student Work、Research Note、Web Article。每项有 0..N 个 Asset（尚未数字化时可为 0）；一个 Asset 可被多项公开叙事引用，但保存与衍生关系不复制。

**Interview 与 Publication 使用各自独立实体和 ID，档案目录将它们投影为 `interview` / `publication` 条目。** 不再为同一访谈额外建立一条 IV 类型 ArchiveItem，避免“双重主记录”。Story 是网站原生叙事，与材料层不同；原公众号快照则是 WA 条目。

照片的说明、拍摄日期、摄影者、出现人物、地点和主题都属于编目记录；文件宽高、格式与校验和属于 Asset。照片不因出现在首页而失去它的档案 ID。

### Interview · 访谈与口述史

`intervieweeIds[1..N]`、`interviewerIds[1..N]`、`occurredAt`、可选 `durationSeconds`、`audioItemIds[0..N]`、`transcriptItemIds[0..N]`、`segments[0..N]`、`interviewMethod`、`summaryMarkdown`、`researchNoteIds[]`。

访谈可以多人参与，录音可以分卷，转写可以有原始版、人工校订版与公开节录版。音频和转写均保留独立材料 ID，通过专用字段绑定。采访地点、人物、主题、调查批次和关联故事通过 typed relations 建立。访谈摘要获准公开不表示整段音频获准公开。

未录音、只有旧笔记或尚未核实录音长度的访谈可以正常编目：`durationSeconds` 省略或为 `null`，`audioItemIds` 可为空。未知不填 `0`，不为了满足字段而估算时长。公开派生访谈也使用同一规则；没有可用录音时，不以其时长或时间戳生成播放导航。

每个 Segment：

| 字段 | 用途 |
|---|---|
| `id` | `DEMO-LTG-IV-2026-001-S001` 等稳定段号；修订后不重排已有 ID |
| `startMs`, `endMs` | 毫秒整数；原音频时间轴，不用浮点秒字符串 |
| `speakerPersonId`, `speakerLabel` | 私有身份引用与公开可用称谓分开 |
| `text`, `themeIds[]` | 可全文检索转写与受控主题 |
| `visibility`, `redactionStatus` | 段级权限与 raw / edited / redacted 状态 |
| `sourceAssetId`, `sourceRevisionHash` | 对齐的音频版本；防止剪辑后时间戳错位 |

构建检查 `0 ≤ startMs < endMs ≤ 对应音频文件时长`、段号唯一、所属访谈一致、音频版本匹配。分卷访谈按 `sourceAssetId` 定位原文件，不能只检查访谈合计时长。公开段、承载它的公开 Interview 与实际播放的公开 Asset 都须获得各自所需审批，片段不能绕过受访者授权或该公开内容的限制；私有原始音频作为来源追溯，不要求其本身公开。公开版采用已剪辑音频时，保存原始段号到公开时间轴的映射；公开段的 `audioItemId` / `audioAssetId` 仅指向获准音频条目和具体文件。播放器只使用该公开文件的时间轴，不能把原始时间戳直接套用。只有公开文本而无音频时不提供可点击的时间跳转。

尚无获准音频时，播放器显示“尚无公开音频”并禁用播放，不生成模拟录音、不让假播放进度冒充真实声音。转写也不能以虚构话语冒充田野引文。

### Story · 公众号再编辑与公共叙事

`subtitle`、`bodyPath`、`coverItemId`、`publishedAt`、`authorIds[]`、`origin`、`sections[]`。正文存 Markdown；ID、字段和关联存 JSON。V1 建议只支持受控 Markdown，默认禁用任意 HTML / JSX，防止未来导入内容执行脚本。

`origin` 包括平台、原文标题、原链接、原发布日期、作者署名、`originalArticleItemId`、可选 `publicationId`。公众号每期先编目为 WA 原文条目，网站改编另有 ST ID；两者通过 `derived-from` 对应。保留原日期与网站发布日期，避免迁移时混成同一天。链接失效时，获准保存的原文快照及来源说明仍能维持出处。

每篇 Story 可关联多个 Fieldwork / Person / Place / Theme / ArchiveItem / Interview，某个段落可关联证据 ID。正文中的每张照片都引用材料 ID，不粘贴无来源图片 URL。人物与素材按其自己的授权分别检查，不继承 Story 的公开权限。

`sections[]` 为有稳定正文锚点的段落证据层：`id`、`heading`、`relatedIds[]` 和 `citations[]`。`relatedIds` 接受实体或 Interview Segment 的 `referenceId`，用于上下文导航；有证据支撑的论断用 `citations` 固定来源版本。每个 citation 包含 `referenceId`、`sourceRevisionHash`，以及可选的页码、段落、毫秒范围等 `locator` 和说明。公开包保留对应的 `sections[]` 与受控 `publicCitation`，不能在导出时丢掉段落到证据的链条。

公开 citation 的目标必须存在于公开包，哈希指向获准公开版本，不泄露私有原件哈希；引用 Segment 时，使用该段所属公开 Interview 的 `revisionHash`，并以 Segment ID 定位。若主档引用的是私有原件，应将该证据映射到经过审批的公开节录或派生材料，再审核论断及定位是否仍成立；私有审计日志保留原件版本到公开证据版本的映射。无法提供安全公开证据时，保留该论述为私有或重新编辑并说明解释性质，不能静默删除引用、却原样保留同一事实论断。

### Theme · 受控主题词

`labelZh`、`labelEn`、`scopeNote`、`broaderThemeId`、`synonyms[]`。一个 Theme 对多种实体做多对多分类；同义词供检索归一，避免“儿童 / Childhood / 孩子”成为三个无关主题。初始受控词可覆盖公共空间、教育、儿童、水、口述史、白族文化、手工、迁移、村庄记忆、社区、可持续、田野方法。

公开 Theme 白名单保留 `labelZh / labelEn / scopeNote / broaderThemeId / synonyms`，其中上级主题只能指向已公开节点。同义词经审核后进入公开检索，不从原始转写自动抽取私人称谓或敏感姓名。

### Collection · 研究者策展集合

`curatorIds[]`、`introductionMarkdown`、`selectionRationale`、`orderedMemberIds[]`、可选 `bodyPath`。一组材料有明确选材逻辑、人工次序与策展解释；成员可来自不同类型实体，且同一材料可进入多个集合。

Theme 是受控分类词；Collection 是有意图的策展叙事。筛选“水”不自动等于专题《消失的水》。集合成员顺序以 `orderedMemberIds` 为唯一权威来源，不另存一份可能不同步的 `curated-in` 关系。

### Publication · 研究文献与成果

`publicationType`、`authors[]`、`publishedAt`、`publisher`、`doi`、`url`、`citationKey`、`citationText`、`assetIds[]`、`isResearchOutput`、`abstract`。作者可有内部人物 ID，也可只按公开出版信息保留姓名。文献不必下载全文才能建记录；受版权限制的 PDF 不随书目条目一起公开。论文草稿可为私有成果，公开论文另有审核版本。

### ResearchProject · 长期问题与论文过程

`workingTitle`、`questions[]`、`methodologyMarkdown`、`codingFramework[]`、`dataNotesMarkdown`、`publicationIds[]`、`methodNoteIds[]`、`researcherIds[]`。框架中每个 Code 有 `code / label / definition / parentCode / themeId / reviewedBy`；分析编码不等同于公共标签。未来研究可有多个 RP，不把整个网站绑定在当前工作论文上。

## 5. 关系与双向浏览

`Relation` 字段：`fromId`、`toId`、`predicate`、`evidenceIds[]`、`certainty`、`note`，另有共用 ID、权限与出处。一个关系连接两个节点，附 0..N 个证据。`certainty` 为陈述、观察、推断或争议；推断必须显示为研究解释，不能当成确定事实。

| 关系 | 来源 → 目标 | 反向界面示例 |
|---|---|---|
| `depicts` | Photograph → Person | 人物页“相关照片” |
| `created-by` | 材料 / Story → Person | 人物页“制作的材料” |
| `recorded-at` | 材料 / Interview → Place | 地点页“在此记录” |
| `participated-in` | Person → Event | 事件页“参与人物” |
| `during-fieldwork` | 材料 / Interview / Event → Fieldwork | 调查页“本次记录” |
| `about-theme` | 任意知识节点 → Theme | 主题筛选结果 |
| `located-in` | Place → Place | 上级地点的相关地点 |
| `occurred-at` | Event → Place | 地点时间线 |
| `mentions` | Story / Interview / 材料 → Person / Place | 人物或地点的相关叙事 |
| `cites` | Story / ResearchProject / Publication → 材料 / 文献 | 被引用次数与来源 |
| `derived-from` | Story / 派生材料 → 原文 / 原材料 | 原文的再编辑版本 |
| `supports` / `contradicts` | 证据材料 → Event / ResearchProject | 研究解释的依据与冲突 |
| `associated-with` | 任意节点 → 任意节点 | 需说明关联缘由；谨慎使用 |

双向浏览不要求存两条镜像关系。存一条语义明确的边，构建时生成 incoming / outgoing 索引。`intervieweeIds`、`interviewerIds`、`assetIds`、`orderedMemberIds`、`origin.originalArticleItemId` 等结构化字段是其关系的唯一权威来源；索引生成器把这些外键转为边，不再要求手写 `interview-of` / `conducted-by` 的重复 Relation。Schema 保留这些谓词供外部数据交换，但同一边不得重复成为两份可编辑事实。

所有引用检查目标存在、类型允许、无非法自环。用于公开导航与内容展示的关系必须指向已公开目标；不可公开的上下文关联不导出，有证据依赖的段落则按上述引用映射规则重新审核。私有来源追溯边仅保留在主档，不要求其目标公开。过滤之后重新计算相关资料数量、筛选计数、主题词云、地图点与时间线。不得出现“8 条相关资料”但只有 3 条公开资料的泄露，也不得通过空白节点暴露私有受访者的存在。

## 6. Asset：原件与公开文件分开

一个 Asset 对应一个不可变文件版本。字段包括 `fileRole`、`storageRef`、`originalFilename`、`mimeType`、`byteSize`、`sha256`、`derivesFromAssetId`、`publicUrl`、`width / height / durationSeconds`、`altText`、`redactionsApplied[]`。

- `preservation-original`：原始照片、原音频、授权扫描；私有或研究限定存储。
- `working-copy`：转写工作版、人工剪辑中间稿；不进入公开构建。
- `public-derivative`：获准发布、完成裁剪/匿名/去 EXIF 的实际文件；只此角色有公开相对路径。

保留原件不覆盖；新公开版产生新 Asset，`derivesFromAssetId` 记录来源。公开包只含公开派生文件的 URL、技术元数据、署名与许可，禁止包含私有 `storageRef`、原始文件名、原件路径、原件校验和或授权凭证路径。图片缩略图、OG 图片、下载原图、字幕、音频波形、PDF OCR、附件与 CDN 缓存都属于发布资产，必须逐一审核。

`derivesFromAssetId`、段的 `sourceAssetId` 等是来源追溯依赖：可以指向私有原件，仅供受控审核使用，不进入公开包，也不要求原件的 visibility 升为公开。公开衍生物凭自身授权范围、脱敏处理和发布审批出站；仍必须满足原材料中相关人物对这些内容和用途的同意，不能用“新文件”绕过原有授权限制。

## 7. 权限、授权与撤回

| visibility | 主档中的含义 | 无登录公开网站 |
|---|---|---|
| `private` | 研究者个人原始/敏感材料 | 不导出正文、元数据或存在性 |
| `research-only` | 获准给特定研究者，仍受用途限制 | 不导出；V1 无研究权限后台 |
| `public-anonymous` | 可公开经过审核的匿名派生版本 | 仅导出获批字段、片段与衍生资产 |
| `public` | 可公开，但仍受署名、期限与许可限制 | 仅导出获批字段、片段与衍生资产 |

权限不只作用于整条记录。人物、关系、片段和文件分别拥有权限。公开内容依赖——实际展示的节点、公开段、播放文件、正文证据与导航目标——都须可公开，授权范围取相关人物、内容与用途的允许范围交集；来源追溯依赖——私有原件、原始段、凭证与派生链——不要求原件公开，相关边留在主档。两类依赖不能混为“原件私有所以衍生物一律不准发布”。人物页获批不自动让关联录音获批；成年人同意露脸不代表同场儿童也同意；家长授权也不自动替代儿童的意愿。未获确认的材料先作为 `private + draft` 入档。

`Consent` 是私有的结构记录：`subjectId`、`consentState`、`scopes[]`（姓名、肖像、声音、引用、儿童作品、位置）、`appliesToIds[]`、`permittedVisibility`、有效期、私有凭证 Asset、采集人、监护人引用、`subjectAssent`、撤回时间和备注。书面授权文件及其真实签名永不出现在公开包。每个授权标明对象和用途，不凭一个 Person 的“已授权”布尔值放行全部后续材料。

发布步骤：

1. 校验主档 Schema、全局 ID 唯一性、外键与类型。
2. 逐人物、逐片段、逐资产核对授权范围、有效期、权利状态和撤回名单；未通过则阻止发布。
3. 人工核对匿名名、间接识别线索、未成年人、家庭位置和研究笔记；完成脱敏文件。
4. 记录源版本哈希与获准字段，审核状态改为 approved；源内容变更会使该批准过期。
5. 按白名单重新序列化公开包，不复制主档对象后删除若干字段。只导出当前批准的版本。
6. 裁剪不可公开的关系和引用，再生成搜索索引、统计、地图、时间线和关联推荐。
7. 扫描公开产物及压缩包：确认无主档目录、授权书、联系方式、原始 EXIF、私有 URL 或敏感片段。预览分享前也执行同一流程。
8. 保存 release 清单和审核日志；日志属于私有域，不进公开站。

撤回时将 Consent 标为 withdrawn，冻结受影响发布；沿关系与派生链找到正文引用、转写、音频、缩略图、OG 图、索引和下载包。重新构建公开包并删除已发布文件、清理缓存。公开稳定 URL 可保留不含身份的通用撤回说明，但不能复述被撤回的内容。备份依机构政策限制访问或删除；撤回日志不公开。V1 先建立清单与人工处置流程，不宣称静态网站能自动撤回全网已经下载的副本。

## 8. 公开包与未来检索

`kind: public` 仅包含：`entities[]`、`assets[]`、`relations[]`、版本与构建时间。公开实体字段是显式白名单；Schema 不接受 `privateIdentity`、`reflectionMarkdown`、`storageRef`、`Consent` 或任意扩展对象。公开资产只能是 `public-derivative`。浏览器、静态全文检索和未来公开 RAG 都只能读取这个派生包。

为未来 semantic search 保留 `retrievalChunk` 定义：`chunkId / entityId / segmentId / revisionHash / text / language / startMs / endMs / publicUrl / visibility / sourceCitation`。每个检索命中可以回到稳定材料、公开版本、转写段或页面锚点。公开与研究专用索引分别建立，不在同一个向量库里仅靠客户端过滤。撤回、过期和源修订时，使相应 chunk 失效并重建；V1 不生成向量、不实现聊天机器人。

AI 辅助的转写、元数据和编码建议记录在 provenance 中，并保留工具与人工复核状态；最终研究解释、发布选择和编码由研究者确认。AI 推断的人物身份、关系与日期不能直接升格为事实。

## 9. 内容目录与维护方式

```text
private-master/                 # 网站仓库之外的受控位置
  metadata/*.json
  originals/                   # 原件与授权文件
  consent/*.json
  release-logs/

website-repository/            # 仅 public-safe 内容
  content/stories/*.md
  content/collections/*.md
  data/public/archive.json
  data/public/search-index.json
  public/assets/               # 已批公开派生文件
  schemas/archive.schema.json
  src/                        # 代码与内容分离
```

新增材料的最小路径是：入档并分配 ID → 填日期、来源、类型和权限 → 建立人物/地点/调查批次/主题关联 → 处理文件与授权 → 审核公开派生版本 → 重建网站。CSV 可作为批量录入与导出格式，但规范数据保留 JSON 中的数组、时间精度、授权及关联；CSV 不承担私有字段与公开字段的混合单表发布。

迁移数据库时，实体记录、Asset、Relation 和 Consent 可映射为独立表，沿用已有 ID 与公开 URL。第一阶段无需决定大型 CMS 或图数据库，不能以页面标题作为后续迁移的键。

## 10. 第一阶段边界与验收

本模型交付结构，不代表权限后台已经实现。当前演示原型只加载明确标识的安全示例；真实材料导入前必须实现导出校验器与发布审核流程。

验收重点：ID 不重用；真实与演示分离；同一访谈只有一个主记录；人物/地点/故事可以往返；不确定日期不伪精确；公开引用不指向私有节点；照片可追溯原件但公开包无原件路径；撤回能列出受影响派生资产；新增一次田野不需要重写页面组件。
